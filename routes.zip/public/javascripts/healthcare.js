var app = angular.module("Healthcare",[]);

