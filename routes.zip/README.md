Hello There,

readme


Do an npm install  - node modules not included 
do npm start 
localhost:8081