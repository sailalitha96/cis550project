Hello There,

readme


Do an npm install  - node modules not included 

Do npm start 
localhost:8081


#########Information ###################
For updated across all pages view queries.sql

Flow of information across website to backend. 


Website- Controllers( public/javascripts/controllers) - Services(public/javascripts/services) - Backend ( AWS - mysql) 

NoSQL used for Storing User Data. Using mongo-db nodejs. 