app.controller("infoController",infoController = function infoController($scope,userInfoService) {
    
});
