app.factory('navigationService',function($window){

  

    // return {
    //     navigateTobenefit: navigatetobenefit
    // };
});